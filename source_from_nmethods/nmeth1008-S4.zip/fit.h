int gauss_fit(float *, int, float *, float *, float *);
