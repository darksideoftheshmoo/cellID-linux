struct complex {
  double r;
  double i;
};
