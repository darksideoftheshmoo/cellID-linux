#include <stdio.h>
#include <stdlib.h>

float get_percentile(float *,int,float);
float partition(float*,int,int,int*,int*);


/**********************************************/
int main(int argc, char *argv[]){

  //Calculate median and MAD of a set of data

  char line[500];

  FILE *fp_in;
  FILE *fp_out;

  int i;
  int n;

  float tmp;
  float *y;

  float median,MAD;

  //Open input and output
  if( (fp_in=fopen("get_median_input.txt","r"))==NULL ){
    printf("Can't open the file get_median_tmp_file.txt from get_median.\n");
    printf("This file should contain a list of numbers which get_median\n");
    printf("will use to calculate the median.\n");
    printf("--->No results are being calculated<---\n");
    return 0;
  }
  if( (fp_out=fopen("get_median_output.txt","w"))==NULL ){
    printf("Can't open the file get_median_output.txt from get_median.\n");
    printf("--->Not calculating any results therefore.<---\n");
    return 0;
  }

  //First read through fp_in to count how many data points
  n=0;
  while((fgets(line,450,fp_in))!=NULL){ //next line
    sscanf(line,"%e",&tmp);
    n++;
  }
  y=(float *)malloc(sizeof(float)*(n+5)); //n+5 just to avoid edge questions
  //Read again
  rewind(fp_in);
  i=0;
  while((fgets(line,450,fp_in))!=NULL){ //next line                              
    sscanf(line,"%e",(y+i));
    i++;
  }
  fclose(fp_in);


  //Get median of this data
  median=get_percentile(y,n,0.5);

  //And now get median of absolute deviations
  for(i=0;i<n;i++){
    y[i]=(y[i]-median);
    if (y[i]<0.0){
      y[i]*=(-1.0);
    }
  }
  MAD=get_percentile(y,n,0.5);
  MAD/=0.6745;

  //Put three values {median,MAD,N} into output file
  fprintf(fp_out,"%e   %e    %i\n",median,MAD,n);
  fclose(fp_out);

  free(y);
  
  return 1;
}

/****************************************************/
float get_percentile(float *y,int ndim,float percentile){

  //Calculate the value of the requested percentile (ie, .5 for median)
  //from the array y[] (which has length ndim)

  int k0,k1; 
  float wt0,wt1;

  int n1,n2,nlt,ngt;
  int kfind;

  float val,val0,val1;

  int first;

  if ((percentile<=0.0)||(percentile>=1.0)){
    printf("Requested bad percentile: %e\n",percentile);
    return 0.0;
  }

  //k0 and k1 will bracket the percentile in question
  //wt1 and wt2 are weights used to calculate final percentile
  k0=((int)(percentile*((float)ndim)));
  wt0=1.0-(percentile*((float)ndim)-((float)k0));
  //wt=1 if percentile points exactly to k0
  if (wt0>=1.0){ //can't be above 1.0 really....
    // Don't need k1 since k0 is exact
    k1=-999.0;
    wt1=0.0;
  }else{
    k1=k0+1;
    wt1=1.0-wt0;
  }
  //change k0 and k1 to indices (which start at 0);
  k0--;
  k1--;
  if (k0<0){
    k0=0;
    k1=1;
  }

  //First find k0
  kfind=k0;
  first=0;

 top:
  n1=0;
  n2=ndim-1;

  //Keep partitioning the data until kfind is between nlt<kfind<ngt
  for(;;){
    val=partition(y,n1,n2,&nlt,&ngt);
    if (kfind<=nlt){
      n2=nlt;
    }else if (kfind>=ngt){
      n1=ngt;
    }else{
      break;
    }
  }

  if (first==0){
    //Check if we also want to get the second bracketing number
    if (k1<0){ //Don't want it, so we're done
      return val;
    }

    first=1;
    val0=val;
    kfind=k1;
    goto top;
  }

  val1=val;

  return (val0*wt0+val1*wt1);

}


/*************************************************/
float partition(float *y, int n1,int n2,int *n_out1, int *n_out2){
  
  //Re-order y[] between n1 and n2 (inclusive) so that
  //y[n1:n_out1-1]<pivot
  //y[nout_1:n_out2]==pivot
  //y[nout_2+1:n2]>pivot
  //where pivot is chosen arbitrarily amont the values y[n1:n2]
  //Return the value of pivot just for fun.
  
  float tmp;
  float pivot;
  int i;
  int ngt;
  int nlt;
 
  if (n1==n2){
    (*n_out1)=n1-1;
    (*n_out2)=n2+1;
    return y[n1];
  }
  if ((n1<0)||(n1>n2)){
    printf("Invalid indices in partition(): %i %i\n",n1,n2);
    (*n_out1)=0;
    (*n_out2)=0;
    return 0.0;
  }
  
  //Choose pivot in middle of array
  i=n1+(n2-n1)/2;
  pivot=y[i];
  //First put everyone less than or equal to pivot to the left of ngt.
  ngt=n2;
  i=n1;
  while(i<ngt){
    if (y[i]>pivot){
      tmp=y[i];
      y[i]=y[ngt];
      y[ngt]=tmp;
      ngt--;
    }else{
      i++;
    }
  }
  //And check the ngt point
  if (y[ngt]<=pivot)ngt++;
  //At this point everything to the right of and including ngt is > pivot.

  //Now sort the <= pivot guys to split into < and =
  i=0;
  nlt=ngt-1; //Note that ngt might be above n2, but only by 1
  while(i<nlt){
    if (y[i]==pivot){
      tmp=y[i];
      y[i]=y[nlt];
      y[nlt]=tmp;
      nlt--;
    }else{
      i++;
    }
  }
  //And check the nlt point
  if (y[nlt]==pivot)nlt--;

  (*n_out1)=nlt;
  (*n_out2)=ngt;

  return pivot;
}


