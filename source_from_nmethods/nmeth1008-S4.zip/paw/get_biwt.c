#include <stdio.h>
#include <stdlib.h>

double get_percentile(double *,int,double);
double partition(double *,int,int,int*,int*);


/**********************************************/
int main(int argc, char *argv[]){

  //Calculate medians and covariance matrix of two dimensional
  //data sets using the biweight midcovariance estimator of the
  //covariance matrix.

  char line[500];

  FILE *fp_in;
  FILE *fp_out;

  int i;
  int n;

  float tmp1,tmp2;
  double *x,*y;
  double *workx,*worky;
  double dx,dy,u2,v2;

  double medx,medy;
  double biwt,madx,mady;
  double varx,vary;

  double lambda=9.0;

  double denx,deny;
  double invn;

  double tmpu,tmpv,tmpu2,tmpv2;



  //Open input and output
  if( (fp_in=fopen("cov_matrix_input.txt","r"))==NULL ){
    printf("Can't open the file cov_matrix_input.txt from get_biwt.\n");
    printf("This file should contain a 2-column list of numbers to\n");
    printf("use to calculate the medians and covariance matrix.\n");
    printf("--->No results are being calculated<---\n");
    return 0;
  }
  if( (fp_out=fopen("cov_matrix_output.txt","w"))==NULL ){
    printf("Can't open the file cov_matrix_output.txt from get_biwt.\n");
    printf("--->Not calculating any results therefore.<---\n");
    return 0;
  }

  //First read through fp_in to count how many data points
  n=0;
  while((fgets(line,450,fp_in))!=NULL){ //next line
    sscanf(line,"%e %e",&tmp1,&tmp2);
    n++;
  }
  medx=0.0;
  medy=0.0;
  varx=0.0;
  vary=0.0;
  biwt=0.0;
  if (n==0){
    goto output;
  }

  x=(double *)malloc(sizeof(double)*(n+5)); //n+5 just to avoid edge questions
  y=(double *)malloc(sizeof(double)*(n+5));
  workx=(double *)malloc(sizeof(double)*(n+5));
  worky=(double *)malloc(sizeof(double)*(n+5));

  //Read again
  rewind(fp_in);
  i=0;
  while((fgets(line,450,fp_in))!=NULL){ //next line
    sscanf(line,"%e %e",&tmp1,&tmp2);
    x[i]=((double)tmp1);
    y[i]=((double)tmp2);
    i++;
  }
  fclose(fp_in);
  printf("  %i\n",n);

  //Get median of this data
  //get_percentile() re-arranges the array, so only use the work arrays
  //since we don't want to lose the correlation between the x[] and y[]
  //arrays.
  for(i=0;i<n;i++){
    workx[i]=x[i];
    worky[i]=y[i];
  }
  medx=get_percentile(workx,n,0.5);
  medy=get_percentile(worky,n,0.5);

  //Use the scaled median-absolute-deviation as estimator of the diagonal
  //parts of covariance matrix
  //And now get median of absolute deviations
  for(i=0;i<n;i++){
    workx[i]=abs(x[i]-medx);
    worky[i]=abs(y[i]-medy);
  }
  madx=get_percentile(workx,n,0.5);
  mady=get_percentile(worky,n,0.5);

  //Now calculate the biwt, which is an estimator of the covariance
  //Factors in denominator
  invn=1.0/((double)n);
  //(I keep scaling by 1/n in sum to keep numbers reasonably
  //sized--perhaps helps? (probably slows it down slightly))
  denx=0.0;
  deny=0.0;
  varx=0.0;
  vary=0.0;
  biwt=0.0;
  for(i=0;i<n;i++){
    dx=(x[i]-medx);
    dy=(y[i]-medy);
    u2=(dx/(lambda*madx));
    v2=(dy/(lambda*mady));
    tmpu=(1.0-u2*u2);
    tmpv=(1.0-v2*v2);
    tmpu2=(tmpu*tmpu);
    tmpv2=(tmpv*tmpv);
    if (u2<1.0){ //(Note that u<1 <==> u^2<1 )
      denx+=(tmpu*(1.0-5.0*u2*u2)*invn);
      varx+=(dx*dx*tmpu2*tmpu2*invn);
    }
    if (v2<1.0){ //(Note that u<1 <==> u^2<1 )
      deny+=(tmpv*(1.0-5.0*v2*v2)*invn);
      vary+=(dy*dy*tmpv2*tmpv2*invn);
    }
    if ((u2<1.0)&&(v2<1.0)){
      //biwt+=((x[i]-medx)*(y[i]-medy)*tmpu*tmpu*tmpv*tmpv*invn);
      biwt+=(dx*dy*tmpu2*tmpv2*invn);
    }
  }

  biwt/=(denx*deny);
  varx/=(denx*denx);
  vary/=(deny*deny);

 output:
  //Write values to output file
  fprintf(fp_out,"%e   %e   %e   %e   %e   %i\n",medx,medy,varx,vary,biwt,n);
  fclose(fp_out);

  free(x);
  free(y);
  free(workx);
  free(worky);
  
  return 1;
}

/****************************************************/
double get_percentile(double *y,int ndim,double percentile){

  //Calculate the value of the requested percentile (ie, .5 for median)
  //from the array y[] (which has length ndim)

  int k0,k1; 
  double wt0,wt1;

  int n1,n2,nlt,ngt;
  int kfind;

  double val,val0,val1;

  int first;

  if ((percentile<=0.0)||(percentile>=1.0)){
    printf("Requested bad percentile: %e\n",percentile);
    return 0.0;
  }

  //k0 and k1 will bracket the percentile in question
  //wt1 and wt2 are weights used to calculate final percentile
  k0=((int)(percentile*((double)ndim)));
  wt0=1.0-(percentile*((double)ndim)-((double)k0));
  //wt=1 if percentile points exactly to k0
  if (wt0>=1.0){ //can't be above 1.0 really....
    // Don't need k1 since k0 is exact
    k1=-999.0;
    wt1=0.0;
  }else{
    k1=k0+1;
    wt1=1.0-wt0;
  }
  //change k0 and k1 to indices (which start at 0);
  k0--;
  k1--;
  if (k0<0){
    k0=0;
    k1=1;
  }

  //First find k0
  kfind=k0;
  first=0;

 top:
  n1=0;
  n2=ndim-1;

  //Keep partitioning the data until kfind is between nlt<kfind<ngt
  for(;;){
    val=partition(y,n1,n2,&nlt,&ngt);
    if (kfind<=nlt){
      n2=nlt;
    }else if (kfind>=ngt){
      n1=ngt;
    }else{
      break;
    }
  }

  if (first==0){
    //Check if we also want to get the second bracketing number
    if (k1<0){ //Don't want it, so we're done
      return val;
    }

    first=1;
    val0=val;
    kfind=k1;
    goto top;
  }

  val1=val;

  return (val0*wt0+val1*wt1);

}


/*************************************************/
double partition(double *y, int n1,int n2,int *n_out1, int *n_out2){
  
  //Re-order y[] between n1 and n2 (inclusive) so that
  //y[n1:n_out1-1]<pivot
  //y[nout_1:n_out2]==pivot
  //y[nout_2+1:n2]>pivot
  //where pivot is chosen arbitrarily amont the values y[n1:n2]
  //Return the value of pivot just for fun.
  
  double tmp;
  double pivot;
  int i;
  int ngt;
  int nlt;
 
  if (n1==n2){
    (*n_out1)=n1-1;
    (*n_out2)=n2+1;
    return y[n1];
  }
  if ((n1<0)||(n1>n2)){
    printf("Invalid indices in partition(): %i %i\n",n1,n2);
    (*n_out1)=0;
    (*n_out2)=0;
    return 0.0;
  }
  
  //Choose pivot in middle of array
  i=n1+(n2-n1)/2;
  pivot=y[i];
  //First put everyone less than or equal to pivot to the left of ngt.
  ngt=n2;
  i=n1;
  while(i<ngt){
    if (y[i]>pivot){
      tmp=y[i];
      y[i]=y[ngt];
      y[ngt]=tmp;
      ngt--;
    }else{
      i++;
    }
  }
  //And check the ngt point
  if (y[ngt]<=pivot)ngt++;
  //At this point everything to the right of and including ngt is > pivot.

  //Now sort the <= pivot guys to split into < and =
  i=0;
  nlt=ngt-1; //Note that ngt might be above n2, but only by 1
  while(i<nlt){
    if (y[i]==pivot){
      tmp=y[i];
      y[i]=y[nlt];
      y[nlt]=tmp;
      nlt--;
    }else{
      i++;
    }
  }
  //And check the nlt point
  if (y[nlt]==pivot)nlt--;

  (*n_out1)=nlt;
  (*n_out2)=ngt;

  return pivot;
}


