void align_image(float *,int,int,int);
