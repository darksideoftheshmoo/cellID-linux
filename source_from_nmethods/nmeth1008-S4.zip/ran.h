//We're going to use the gnu-C library routine rand() to
//make random numbers. Could replace this was something
//better if needs be.

void set_random_seed(unsigned int);
float gaussian(float,float);
float flat_ran(void);
int poisson(float);
float exponential(float,float);
