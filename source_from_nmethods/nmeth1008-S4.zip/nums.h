void add_numbers_to_data(int,int,int, int *, int, int);
void digits_to_string(char *, int, int);
void date_stamp(int,int,int);
void time_stamp(int,int,int);
int search_data_for_number(int,int*,int*,int,int*,int,int);
