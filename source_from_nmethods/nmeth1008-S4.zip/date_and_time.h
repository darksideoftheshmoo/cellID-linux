int get_date_and_time(char *, int *, int *,float*,float*);
void JulianToYMD(unsigned int, unsigned short *, unsigned char *,
                 unsigned char *);
void Int_To_Hours_Minutes_Seconds(unsigned int, int *, int *, int *);
float get_exposure(char *);
