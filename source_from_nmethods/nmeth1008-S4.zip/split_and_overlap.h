int *find_split_regions(float *, int, int);
void calculate_split_offset(int *,float *,
			    float *,float *,float *,float *,int, int);
