struct point {
  int i,j;
  struct point *next;
  struct point *prev;
};
