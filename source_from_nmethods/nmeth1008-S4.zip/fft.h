#ifndef _complex_
   #define _complex_
   #include "complex.h"
#endif
struct complex *FFT_1d(struct complex *, int, int);
struct complex *FFT_2d(struct complex *, int, int);
