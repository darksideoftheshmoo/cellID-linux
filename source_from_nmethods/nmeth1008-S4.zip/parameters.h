extern float max_d_over_s_cut;
extern int max_pixels_per_cell;
extern int min_pixels_per_cell;
extern float background_reject_factor;
extern float max_split_d_over_minor;
extern float I_over_U_for_match;
#ifndef _parameters_
#define _parameters_
float max_d_over_s_cut;
int max_pixels_per_cell;
int min_pixels_per_cell;
float background_reject_factor;
float max_split_d_over_minor;
float I_over_U_for_match;
#endif
